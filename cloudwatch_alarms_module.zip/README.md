# CloudWatch Alarms Module

This module is used to create CloudWatch Alarms for various AWS services like EC2, S3, ALB, RDS, and more. You can use this module to monitor your AWS resources and send notifications using SNS if any alarm is triggered.

## Features

- EC2 Instance Termination Alarms
- EC2 CPU Utilization Alarms
- ALB HTTP 4XX/5XX Failures Alarms
- EBS Latency Alarms
- RDS CPU, Memory, Disk, and Latency Alarms
- S3 Bucket Storage and File Deletion Alarms
- Support for optional SNS notifications

## Usage

### Example Usage:

```hcl
module "cloudwatch_alarms" {
  source = "./cloudwatch_alarms"

  alarms = {
    ec2_termination_alarm = {
      alarm_name          = "EC2_Instance_Termination_Alarm"
      metric_name         = "TerminatedInstances"
      namespace           = "AWS/EC2"
      statistic           = "Sum"
      threshold           = 1
      comparison_operator = "GreaterThanThreshold"
      evaluation_periods  = 1
      period              = 60
      actions_enabled     = true
      sns_topic_arn       = ""
      dimensions = {
        InstanceId = "i-xxxxxxxxxxxxxxxxx"
      }
    }
  }
}
```

## Variables

- `alarms`: A map of alarm configurations. Each alarm has its own set of parameters.
- `sns_topic_arn`: (Optional) SNS topic ARN to be used for notifications.

## Outputs

- `alarm_names`: List of created alarm names.

## Requirements

- Terraform >= 0.12
- AWS provider
