
# ASG Health Check Terraform Module

This module deploys a Lambda function to monitor the health of EC2 instances within multiple Auto Scaling Groups (ASGs). The Lambda function periodically checks the health of each instance in specified ASGs, sends custom metrics to CloudWatch, and triggers CloudWatch alarms if the number of unhealthy instances in an ASG exceeds a specified threshold.

## Features
- Deploys a Lambda function to monitor ASG instance health.
- Creates a CloudWatch Event Rule to invoke the Lambda function every 5 minutes.
- Sets up a CloudWatch alarm for each ASG to alert when the number of unhealthy instances exceeds a specified threshold.
- Outputs the Lambda function name and CloudWatch alarm names for easy access.

## Prerequisites
- AWS Lambda deployment package (`.zip` file) containing the Python script `lambda_function.py`.
- The Lambda function assumes an IAM role with necessary permissions.

## Usage

### Inputs

| Name                | Description                                                                | Type           | Default                      | Required |
|---------------------|----------------------------------------------------------------------------|----------------|------------------------------|----------|
| `region`            | AWS region where resources are created.                                   | `string`       | `""`                         | Yes      |
| `asg_names`         | List of Auto Scaling Group names to monitor.                              | `set(string)`  | n/a                          | Yes      |
| `lambda_name`       | Name of the Lambda function.                                              | `string`       | n/a                          | Yes      |
| `lambda_zip_path`   | Path to the Lambda deployment package (zip file).                         | `string`       | n/a                          | Yes      |
| `lambda_handler`    | Lambda handler (entry point) for the function.                            | `string`       | `lambda_function.lambda_handler` | No       |
| `unhealthy_threshold` | Threshold for unhealthy instance count to trigger alarm.               | `number`       | `1`                          | No       |
| `alarm_action`      | ARN of the action to take when the alarm is triggered (e.g., SNS topic).  | `string`       | n/a                          | Yes      |

### Outputs

| Name                   | Description                                      |
|------------------------|--------------------------------------------------|
| `lambda_function_name` | The name of the Lambda function.                 |
| `cloudwatch_alarm_names` | The names of the CloudWatch alarms per ASG.    |

### Example Usage

```hcl
module "asg_health_check" {
  source              = "./asg_health_check"
  region              = "us-west-2"
  asg_names           = ["example-asg-1", "example-asg-2"]
  lambda_name         = "asg_health_check_lambda"
  lambda_zip_path     = "path/to/lambda_function.zip"
  unhealthy_threshold = 2
  alarm_action        = "arn:aws:sns:us-west-2:123456789012:example-sns-topic"
}
```

## Deployment

1. Download or clone this repository.
2. Modify the example usage as needed and add it to your Terraform configuration.
3. Run `terraform init` to initialize the module.
4. Run `terraform apply` to deploy the module.
