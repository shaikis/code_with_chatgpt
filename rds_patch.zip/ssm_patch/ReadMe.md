# AWS Systems Manager Patch Module with CloudWatch Alarms and Dashboard

## Overview

This Terraform module automates patch management for AWS EC2 instances using AWS Systems Manager (SSM). It allows you to configure patch baselines, patch groups, maintenance windows, and logging to S3. Additionally, it includes CloudWatch Alarms and Dashboards to monitor patching activities such as failed patches and successful patch deployments.

## Features
- **Patch Baseline**: Create a patch baseline with approval rules for various OS (Amazon Linux, Windows, RHEL, etc.).
- **Maintenance Windows**: Configurable maintenance windows for patching operations.
- **S3 Bucket Logging**: Logs patching activities to a specified S3 bucket for future auditing.
- **CloudWatch Alarms**: Monitor patching failures with CloudWatch alarms.
- **CloudWatch Dashboards**: Visualize patching metrics such as failed and successful patches in a CloudWatch dashboard.

## Usage

```hcl
module "ssm_patch" {
  source = "./modules/ssm_patch"

  patch_logs_s3_bucket        = "my-patch-logs-bucket"
  patch_baselines = {
    "example-baseline" = {
      name              = "MyPatchBaseline"
      description       = "Patch baseline for Amazon Linux 2"
      approval_after_days = 7
      approval_products = ["AmazonLinux2"]
    }
  }
  patch_groups = {
    "example-group" = "example-baseline"
  }
  maintenance_windows = {
    "example-window" = {
      name        = "MyMaintenanceWindow"
      schedule    = "cron(0 2 ? * 6 *)"
      duration    = 2
      cutoff      = 1
    }
  }
  alarm_sns_topic_arn        = "arn:aws:sns:us-west-2:123456789012:my-patch-alarm-topic"
}
