# Terraform Module for Restoring Oracle RDS from Snapshot (Oracle EE 19c)

This Terraform module restores **Oracle RDS** instances from existing snapshots. The module supports multiple RDS instance restores using `for_each`. It is specifically configured for **Oracle EE 19c** (version 19.0.0.0) and supports creating event subscriptions for RDS events like failures and creation.

## Features

- Restore Oracle RDS from a snapshot (Oracle EE 19c version).
- Supports restoring multiple RDS instances using `for_each`.
- Create event subscriptions to monitor RDS events.
- Optionally configure backup retention and maintenance windows.

## Requirements

- **Terraform** v1.0 or higher
- **AWS Provider** configured with proper IAM permissions to manage RDS instances and clusters
- **RDS Snapshot** to restore from

## Input Variables

| Name                         | Type            | Description                                                                   | Default Value              |
|------------------------------|-----------------|-------------------------------------------------------------------------------|----------------------------|
| `region`                     | string          | AWS region where the RDS resources will be created.                            | `us-west-2`                |
| `db_instances`               | map(object)     | A map of RDS instance identifiers and configurations.                          |                            |
| `db_subnet_group_name`       | string          | The name of the DB subnet group.                                               |                            |
| `sns_topic_arn`              | string          | The ARN of the SNS topic for event subscriptions.                              |                            |
| `backup_retention_period`    | number          | The backup retention period in days.                                           | `7`                        |
| `preferred_backup_window`    | string          | The preferred backup window for the RDS instance.                             | `02:00-03:00`              |
| `preferred_maintenance_window` | string        | The preferred maintenance window for the RDS instance.                         | `Sun:05:00-Sun:06:00`       |
| `publicly_accessible`        | bool            | Whether the RDS instance is publicly accessible.                               | `false`                    |
| `default_tags`               | map(string)     | A map of tags to apply to the RDS resources.                                   | `{}`                       |

## Example Usage

```hcl
module "restore_oracle_rds" {
  source = "./modules/restore_oracle_rds_from_snapshot"

  region               = "us-west-2"
  db_instances = {
    "restored-instance-1" = {
      snapshot_identifier = "rds:snapshot-id-1"
      db_instance_class   = "db.r5.large"
    },
    "restored-instance-2" = {
      snapshot_identifier = "rds:snapshot-id-2"
      db_instance_class   = "db.r5.large"
    }
  }
  db_subnet_group_name = "my-db-subnet-group"
  sns_topic_arn        = "arn:aws:sns:us-west-2:123456789012:rds-event-topic"
  default_tags = {
    Environment = "Production"
  }
}
