## Usage of this module.
```
module "rds_patch" {
  source = "./modules/rds_patch"

  region               = "us-west-2"
  sns_topic_arn        = "arn:aws:sns:us-west-2:123456789012:rds-patch-topic"
  alarm_sns_topic_arn  = "arn:aws:sns:us-west-2:123456789012:rds-patch-alarm-topic"
  db_instances = {
    "oracle-db-instance-1" = {
      instance_class         = "db.m5.large"
      allocated_storage      = 100
      engine_version         = "19.0.0.0.ru-2021-07.rur-2021-07-22.r1"  # Oracle 19c version
      maintenance_window     = "Sun:03:00-Sun:05:00"
      backup_retention_period = 7
      tags = {
        Environment = "Production"
      }
    },
    "oracle-db-instance-2" = {
      instance_class         = "db.m5.large"
      allocated_storage      = 100
      engine_version         = "19.0.0.0.ru-2021-07.rur-2021-07-22.r1"  # Oracle 19c version
      maintenance_window     = "Sun:05:00-Sun:07:00"
      backup_retention_period = 7
      tags = {
        Environment = "Staging"
      }
    }
  }
}
```

