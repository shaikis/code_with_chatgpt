# Terraform Module for Restoring EC2 Instances from AMI or Snapshot

This Terraform module allows you to restore **EC2 instances** from an **AMI** or **Snapshot**. It is a reusable module that supports restoring multiple EC2 instances with configurable instance types, volumes, and networking settings.

The module also supports copying AMIs between regions if needed.

## Features

- Restore EC2 instances from an **AMI** or **Snapshot**.
- Support for **multiple EC2 instances** using `for_each`.
- Optionally copy AMIs to another region.
- Configure instance types, volumes, and tags.
- Enable or disable **CloudWatch monitoring**.
- Option to **disable API termination** to prevent accidental termination of EC2 instances.

## Requirements

- **Terraform** v1.0 or higher.
- **AWS Provider** with appropriate IAM permissions to manage EC2 instances, AMIs, and snapshots.
- **AMI** or **Snapshot** to restore the EC2 instance.

## Input Variables

| Name                         | Type            | Description                                                                                 | Default Value            |
|------------------------------|-----------------|---------------------------------------------------------------------------------------------|--------------------------|
| `region`                     | string          | AWS region where the EC2 instances will be restored.                                        | `us-west-2`              |
| `ec2_instances`               | map(object)     | A map of EC2 instances to restore from AMI or snapshot. Includes details like instance type, AMI, subnet, etc. |                          |
| `default_tags`                | map(string)     | A map of tags to apply to the EC2 resources.                                                 | `{}`                     |
| `enable_monitoring`           | bool            | Enable CloudWatch monitoring for EC2 instances.                                             | `false`                  |
| `disable_api_termination`    | bool            | Disable termination of EC2 instances through the AWS API.                                   | `false`                  |
| `destination_region`          | string          | The region to which the AMI should be copied (if applicable).                               |                          |

## Example Usage

```hcl
module "restore_ec2" {
  source = "./modules/restore_ec2_instance"

  region = "us-west-2"
  ec2_instances = {
    "instance-1" = {
      ami_id                 = "ami-0abcd1234efgh5678"
      instance_type          = "t2.medium"
      key_name               = "my-key-pair"
      subnet_id             = "subnet-12345abc"
      iam_instance_profile  = "EC2InstanceProfile"
      volume_size           = 20
      volume_type           = "gp2"
      associate_public_ip_address = true
      device_name           = "/dev/sda1"
      snapshot_id           = "snap-0abcd1234efgh5678"
    }
  }
  destination_region = "us-east-1"
}
