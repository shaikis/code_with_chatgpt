
# AWS CloudTrail & CloudWatch Terraform Module

This module deploys an AWS CloudTrail setup to capture, log, and monitor user actions, such as sign-ins, resource modifications, creations, deletions, and unauthorized access attempts. Additionally, it creates a CloudWatch dashboard to visualize these activities and optionally sets up CloudWatch alarms for suspicious activities.

## Features

- **CloudTrail Logging**: Enables CloudTrail to capture actions across your AWS account, including management events and service actions.
- **CloudWatch Log Group**: Stores CloudTrail logs in a dedicated CloudWatch Log Group with a retention period of 60 days.
- **Metric Filters**: Tracks specific actions:
  - Successful and failed sign-ins
  - Anonymous access attempts
  - Create, delete, modify, and update actions
- **CloudWatch Dashboard**: Provides real-time visualization of key metrics related to user actions.
- **CloudWatch Alarms (Optional)**: Notifies you of thresholds being reached for high-risk activities like frequent deletions.

## Usage

```hcl
module "cloudtrail_logging" {
  source = "./modules/aws_cloudtrail_logging"  # Adjust path if needed
  environment = "prod"
  region      = "us-east-1"
  alarm_thresholds = {
    create_actions = 10
    delete_actions = 5
  }
}
```
