# Terraform Module for Amazon Elastic File System (EFS)

This Terraform module allows you to create **Amazon Elastic File System (EFS)** with flexible configurations. It supports various options such as **General Purpose**, **MaxIO**, and custom throughput modes, encryption, lifecycle policies, and backup configurations. The module uses `for_each` and `map(object)` to make it reusable and manage multiple EFS file systems.

## Features

- Create multiple EFS file systems with different configurations.
- Supports **General Purpose** and **MaxIO** performance modes.
- Option to configure **Provisioned Throughput**, **Encryption** (with KMS), and **Backup Policy**.
- Option to define **mount targets** in specific subnets with custom security groups.
- Easily extendable to support more configurations as needed.

## Requirements

- **Terraform** v1.0 or higher.
- **AWS Provider** with appropriate IAM permissions to manage EFS resources.

## Input Variables

| Name                        | Type             | Description                                                                 | Default Value             |
|-----------------------------|------------------|-----------------------------------------------------------------------------|---------------------------|
| `region`                    | string           | AWS region where the resources will be created.                             | `us-west-2`               |
| `efs_file_systems`           | map(object)      | A map of EFS file systems to create, where each key is a file system name and the value contains its configuration. |                           |

### EFS File System Configuration

- **creation_token**: A unique identifier for the file system.
- **performance_mode**: The performance mode (`generalPurpose` or `maxIO`).
- **throughput_mode**: The throughput mode (`bursting` or `provisioned`).
- **provisioned_throughput_in_mibps**: The provisioned throughput in MiB/s (only applicable if `throughput_mode` is `provisioned`).
- **encrypted**: Boolean to indicate whether the file system should be encrypted.
- **kms_key_id**: The KMS key ID used to encrypt the file system (required if `encrypted` is true).
- **lifecycle_policy**: The lifecycle policy for the file system (`AFTER_7_DAYS`, `AFTER_30_DAYS`, `AFTER_60_DAYS`).
- **backup_policy_status**: The backup policy status (`ENABLED` or `DISABLED`).
- **tags**: Tags to apply to the EFS resources.
- **mount_targets**: A list of objects that define the mount targets. Each object includes:
  - `subnet_id`: The subnet ID for the mount target.
  - `security_groups`: A list of security group IDs for the mount target.

## Example Usage

```hcl
module "efs" {
  source = "./efs_module"  # Path to the fsx module

  region = "us-west-2"  # AWS region to deploy resources

  efs_file_systems = {
    "general_purpose_fs" = {
      creation_token              = "generalPurposeEFS"
      performance_mode            = "generalPurpose"
      throughput_mode             = "bursting"
      provisioned_throughput_in_mibps =
```