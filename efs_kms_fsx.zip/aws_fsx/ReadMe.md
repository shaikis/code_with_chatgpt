# Terraform Module for Amazon FSx (Windows, Lustre, OpenZFS, NetApp ONTAP)

This Terraform module allows you to create **Amazon FSx File Systems** (Windows File Server, Lustre, OpenZFS, and NetApp ONTAP) in AWS. The module is reusable and supports multiple file systems with different configurations. It uses `for_each` to create resources based on the provided `storage_type`.

## Features

- Supports **FSx for Windows File Server**, **FSx for Lustre**, **FSx for OpenZFS**, and **FSx for NetApp ONTAP**.
- Configures the file system according to the provided parameters.
- Supports creating multiple file systems with different configurations.
- Supports configurations for throughput capacity, backup retention, AD integration, etc.


```
module "fsx" {
  source = "./fsx_module"  # Path to the fsx module

  region = "us-west-2"  # AWS region to deploy resources

  fsx_file_systems = {
    # FSx Windows File Server
    "windows_file_system" = {
      storage_type             = "Windows"
      subnet_id               = "subnet-xxxxxxxx"
      security_group_ids      = ["sg-xxxxxxxx"]
      tags                    = {
        Name = "WindowsFS"
      }
      throughput_capacity     = 256
      deployment_type         = "SINGLE_AZ_1"
      active_directory_id     = "ad-xxxxxxxx"
      preferred_subnet_id     = "subnet-yyyyyyyy"
      multi_az                = false
      daily_automatic_backup_start_time = "04:00"
      automatic_backup_retention_days = 7
    }

    # FSx Lustre File System
    "lustre_file_system" = {
      storage_type             = "Lustre"
      subnet_id               = "subnet-xxxxxxxx"
      security_group_ids      = ["sg-xxxxxxxx"]
      tags                    = {
        Name = "LustreFS"
      }
      throughput_capacity     = 2000
      deployment_type         = "SINGLE_AZ_1"
      per_unit_storage_throughput = 200
      auto_import_policy      = "NEW_FILES_ONLY"
      import_path             = "s3://your-s3-bucket/lustre-import"
    }

    # FSx OpenZFS File System
    "openzfs_file_system" = {
      storage_type             = "OpenZFS"
      subnet_id               = "subnet-xxxxxxxx"
      security_group_ids      = ["sg-xxxxxxxx"]
      tags                    = {
        Name = "OpenZFSFS"
      }
      throughput_capacity     = 256
      deployment_type         = "SINGLE_AZ_1"
      copy_tags_to_backups    = true
      daily_automatic_backup_start_time = "06:00"
      automatic_backup_retention_days = 14
    }

    # FSx NetApp ONTAP File System
    "netapp_ontap_file_system" = {
      storage_type             = "NetAppONTAP"
      subnet_id               = "subnet-xxxxxxxx"
      security_group_ids      = ["sg-xxxxxxxx"]
      tags                    = {
        Name = "NetAppONTAPFS"
      }
      throughput_capacity     = 1024
      deployment_type         = "MULTI_AZ_1"
      copy_tags_to_backups    = true
      automatic_backup_retention_days = 7
      daily_automatic_backup_start_time = "07:00"
    }
  }
}

```
## Requirements

- **Terraform** v1.0 or higher.
- **AWS Provider** with appropriate IAM permissions to manage FSx file systems.

## Input Variables

| Name                         | Type            | Description                                                                                 | Default Value            |
|------------------------------|-----------------|---------------------------------------------------------------------------------------------|--------------------------|
| `region`                     | string          | AWS region where the FSx file systems will be created.                                      | `us-west-2`              |
| `fsx_file_systems`            | map(object)     | A map of FSx file systems to create, where each key represents a file system and the value contains the configuration. |                          |

### FSx File System Configuration

- **storage_type**: Type of FSx file system (`Windows`, `Lustre`, `OpenZFS`, `NetAppONTAP`).
- **subnet_id**: The subnet ID where the FSx file system will be deployed.
- **security_group_ids**: The security groups to apply to the FSx file system.
- **tags**: Tags to apply to the FSx resources.
- **throughput_capacity**: The throughput capacity of the file system.
- **deployment_type**: The deployment type (`SINGLE_AZ_1`, `SINGLE_AZ_2`, or `MULTI_AZ_1`).
- **active_directory_id**: The Active Directory ID (only for Windows File Server).
- **preferred_subnet_id**: The preferred subnet ID for Windows File Server.
- **multi_az**: Enable or disable multi-AZ deployment (only for Windows File Server).
- **daily_automatic_backup_start_time**: The start time for automatic backups (only for Windows File Server and OpenZFS).
- **automatic_backup_retention_days**: Number of days to retain automatic backups (only for Windows File Server and OpenZFS).
- **per_unit_storage_throughput**: The throughput capacity per unit of storage (only for Lustre and NetApp ONTAP
