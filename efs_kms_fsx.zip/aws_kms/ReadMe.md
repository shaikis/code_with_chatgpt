# Terraform Module for AWS KMS Keys

This Terraform module allows you to create AWS KMS keys with flexible configurations using `for_each` and `map(object)` to handle multiple keys. The module can be used to create different KMS keys for various AWS services like **EBS**, **RDS**, **EFS/FSx**, and **S3** buckets with different configurations for encryption.

## Features

- Supports automatic key rotation.
- Configurable lifecycle management (e.g., preventing key destruction).
- Create multiple KMS keys with different configurations using `for_each`.
- Full control over key policies, descriptions, and encryption contexts.
- Allows you to create KMS aliases for easy reference in resource configurations.

## Requirements

- **Terraform** v1.0 or higher.
- **AWS Provider** with appropriate IAM permissions to manage KMS keys.

## Input Variables

| Name                     | Type             | Description                                                                                   | Default Value  |
|--------------------------|------------------|-----------------------------------------------------------------------------------------------|----------------|
| `region`                  | string           | The AWS region where resources will be created.                                               | `us-west-2`    |
| `kms_keys`                | map(object)      | A map of KMS keys to create, where each key represents a KMS key and the value contains its configuration. |                |

### KMS Key Configuration

- **description**: A description for the KMS key.
- **key_usage**: Defines the usage of the KMS key (`ENCRYPT_DECRYPT`, `SIGN_VERIFY`).
- **customer_master_key_spec**: The key spec for the KMS key (`SYMMETRIC_DEFAULT`, `HMAC_SHA_256`, etc.).
- **policy**: The key policy in JSON format for managing permissions.
- **enable_key_rotation**: Whether to enable automatic key rotation (`true` or `false`).
- **prevent_destroy**: Whether to prevent the key from being destroyed (set to `true` to prevent deletion).
- **tags**: Tags to apply to the KMS key.

## Example Usage

```
module "kms_keys" {
  source = "./kms_module"  # Path to the kms module

  region = "us-west-2"     # AWS region to deploy resources

  kms_keys = {
    "ebs_encryption_key" = {
      description                = "EBS Encryption KMS key"
      key_usage                  = "ENCRYPT_DECRYPT"
      customer_master_key_spec   = "SYMMETRIC_DEFAULT"
      policy                     = jsonencode({
        Version = "2012-10-17"
        Statement = [
          {
            Effect    = "Allow"
            Action    = "kms:Encrypt"
            Resource  = "*"
            Principal = {
              AWS = "*"
            }
          }
        ]
      })
      enable_key_rotation        = true
      prevent_destroy            = false
      tags = {
        Environment = "dev"
        Application = "ebs"
      }
    }

    "rds_encryption_key" = {
      description                = "RDS Encryption KMS key"
      key_usage                  = "ENCRYPT_DECRYPT"
      customer_master_key_spec   = "SYMMETRIC_DEFAULT"
      policy                     = jsonencode({
        Version = "2012-10-17"
        Statement = [
          {
            Effect    = "Allow"
            Action    = "kms:Encrypt"
            Resource  = "*"
            Principal = {
              AWS = "*"
            }
          }
        ]
      })
      enable_key_rotation        = true
      prevent_destroy            = false
      tags = {
        Environment = "prod"
        Application = "rds"
      }
    }

    "efs_encryption_key" = {
      description                = "EFS Encryption KMS key"
      key_usage                  = "ENCRYPT_DECRYPT"
      customer_master_key_spec   = "SYMMETRIC_DEFAULT"
      policy                     = jsonencode({
        Version = "2012-10-17"
        Statement = [
          {
            Effect    = "Allow"
            Action    = "kms:Encrypt"
            Resource  = "*"
            Principal = {
              AWS = "*"
            }
          }
        ]
      })
      enable_key_rotation        = true
      prevent_destroy            = false
      tags = {
        Environment = "staging"
        Application = "efs"
      }
    }

    "s3_encryption_key" = {
      description                = "S3 Encryption KMS key"
      key_usage                  = "ENCRYPT_DECRYPT"
      customer_master_key_spec   = "SYMMETRIC_DEFAULT"
      policy                     = jsonencode({
        Version = "2012-10-17"
        Statement = [
          {
            Effect    = "Allow"
            Action    = "kms:Encrypt"
            Resource  = "*"
            Principal = {
              AWS = "*"
            }
          }
        ]
      })
      enable_key_rotation        = true
      prevent_destroy            = false
      tags = {
        Environment = "prod"
        Application = "s3"
      }
    }
  }
}

output "kms_key_ids" {
  value = module.kms_keys.kms_key_ids
}

output "kms_key_arns" {
  value = module.kms_keys.kms_key_arns
}

```