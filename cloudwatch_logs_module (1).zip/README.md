# CloudWatch Logs Terraform Module

This Terraform module creates CloudWatch log groups and configures CloudWatch Events to capture actions from specific AWS services: ASG, S3, and EBS. It is designed to be reusable, leveraging `for_each` for dynamic resource creation.

## Module Structure

The module consists of three main Terraform files:

- `main.tf`: Contains the logic for setting up CloudWatch log groups and configuring event rules and targets.
- `variables.tf`: Defines variables to make the module reusable and configurable.
- `outputs.tf`: Defines outputs for accessing the created log group ARNs.

## Usage

To use this module, specify the event patterns and configurations for log groups:

```hcl
module "cloudwatch_logs" {
  source      = "./cloudwatch_logs_module"
  environment = "prod"

  service_log_config = {
    asg = {
      log_name          = "asg-actions"
      retention_in_days = 7
      tags              = { "Team" = "Operations" }
    }
    s3 = {
      log_name          = "s3-actions"
      retention_in_days = 14
      tags              = { "Team" = "Storage" }
    }
    ebs = {
      log_name          = "ebs-actions"
      retention_in_days = 30
      tags              = { "Team" = "Storage" }
    }
  }

  service_event_patterns = {
    asg = {
      "source" = ["aws.autoscaling"]
      "detail-type" = ["EC2 Instance Launch Successful", "EC2 Instance Terminate Successful"]
    }
    s3 = {
      "source" = ["aws.s3"]
      "detail-type" = ["AWS API Call via CloudTrail"]
      "detail" = {
        "eventSource" = ["s3.amazonaws.com"]
      }
    }
    ebs = {
      "source" = ["aws.ec2"]
      "detail-type" = ["AWS API Call via CloudTrail"]
      "detail" = {
        "eventName" = ["AttachVolume", "DetachVolume"]
      }
    }
  }
}
```

## Variables

- `service_log_config`: Map defining the configuration for each log group.
- `service_event_patterns`: Event patterns to match actions for each service.
- `environment`: Specifies the environment tag.

## Outputs

- `log_group_arns`: Returns the ARNs of the created CloudWatch Log Groups.
